#ifndef __STRTOOLS_H
#define __STRTOOLS_H

/* str_contains_intval(): check if input string contains an integer value
   returns 1 if so, 0 if not
*/
int		str_contains_intval(const char *str);

#endif

